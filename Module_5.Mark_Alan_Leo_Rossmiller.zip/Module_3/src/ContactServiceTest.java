import static org.junit.Assert.*;
import org.junit.Test;
public class ContactServiceTest {

	@Test
	public void testingAddContact() {
		ContactService contactService = new ContactService();
		Contact contact;
		
		System.out.println("Testing contactService.addContact() with valid inputs");
		contact = contactService.addContact("0", "Mark", "Rossmiller", "5154021663", "4220 87th Street");
		assertNotNull(contact);
		
		System.out.println("Testing contactService.addContact() with duplicate ID");
		contact = contactService.addContact("0", "Mark", "Rossmiller", "5154021663", "4220 87th Street");
		assertNull(contact);
		
		System.out.println("Testing contactService.addContact() with invalid inputs");
		contact = contactService.addContact("1", "Mark Alan Leo Rossmiller", "Rossmiller", "05154021663", "4220 87th Street");
		assertNull(contact);
	}
	
	@Test
	public void testingDeleteContact() {
		ContactService contactService = new ContactService();
		Contact contact;
		
		contact = contactService.addContact("0",  "Mark",  "Rossmiller",  "5154021663",  "4220 87th Street");
		
		System.out.println("Testing contactService.deleteContact() with invalid ID");
		assertFalse(contactService.deleteContact("1"));
		
		System.out.println("Testing contactService.deleteContact() with valid ID");
		assertTrue(contactService.deleteContact("0"));
	}
	
	@Test
	public void testingUpdateContact() {
		ContactService contactService = new ContactService();
		Contact contact;
		
		contact = contactService.addContact("0",  "Mark", "Rossmiller",  "5154021663",  "4220 87th Street");
		
		/* firstName */
		System.out.println("Testing contactService.updateFirstName() with valid input and ID");
		assertTrue(contactService.updateFirstName("0", "Bob"));
		System.out.println("Testing contactService.updateFirstName() with invalid ID");
		assertFalse(contactService.updateFirstName("1", "Alice"));
		System.out.println("Testing contactService.updateFirstName() with invalid input");
		assertFalse(contactService.updateFirstName("0", "Mark Alan Leo Rossmiller"));
		
		/* lastName */
		System.out.println("Testing contactService.updateLastName() with valid input and ID");
		assertTrue(contactService.updateLastName("0", "Yao"));
		System.out.println("Testing contactService.updateLastName() with invalid ID");
		assertFalse(contactService.updateLastName("1", "Rossmiller"));
		System.out.println("Testing contactService.updateLastName() with invalid input");
		assertFalse(contactService.updateLastName("0", "Mark Alan Leo Rossmiller"));
		
		/* Number */
		System.out.println("Testing contactService.updateNumber() with valid input and ID");
		assertTrue(contactService.updateNumber("0", "4441310960"));
		System.out.println("Testing contactService.updateNumber() with invalid ID");
		assertFalse(contactService.updateNumber("1", "5154021663"));
		System.out.println("Testing contactService.updateNumber() with invalid input");
		assertFalse(contactService.updateNumber("0", ""));
		
		/* Address */
		System.out.println("Testing contactService.updateAddress() with valid input and ID");
		assertTrue(contactService.updateAddress("0", "5126 Fourth Street"));
		System.out.println("Testing contactService.updateAddress() with invalid ID");
		assertFalse(contactService.updateAddress("1", "4220 87th Street"));
		System.out.println("Testing contactService.updateAddress() with invalid input");
		assertFalse(contactService.updateAddress("0", ""));
	}
}
