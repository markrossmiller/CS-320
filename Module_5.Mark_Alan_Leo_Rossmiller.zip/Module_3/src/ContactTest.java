import static org.junit.Assert.*;
import org.junit.Test;
public class ContactTest {
	
	@Test
	public void testingInstance() {
		Contact contact = null;
		try {
			contact = new Contact("0123456789");
		} catch (InstantiationException e) {
		}
		System.out.println("Testing Contact(\"0123456789\")");
		assertNotNull(contact);
		
		contact = null;
		try {
			contact = new Contact("");
		} catch (InstantiationException e) {
		}
		
		System.out.println("Testing Contact(\"\")");
		assertNull(contact);
		
		contact = null;
		try {
			contact = new Contact("0123456789abcdef");
		} catch (InstantiationException e) {
		}
		System.out.println("Testing Contact(\"0123456789abcdef\")");
		assertNull(contact);
		
	}
	
	@Test
	public void testingSet() {
		Contact contact;
		try {
			contact = new Contact("0");
			
			/* firstName */
			try {
				contact.setFirstName("Mark");
			}
			catch (IllegalArgumentException e) {
			}
			System.out.println("Testing contact.setFirstName(\"Mark\")");
			assertEquals("Mark", contact.getFirstName());
			try {
				contact.setFirstName("");
			} catch(IllegalArgumentException e) {
			}
			System.out.println("Testing contact.setFirstName(\"\")");
			assertNotEquals("", contact.getFirstName());
			try {
				contact.setFirstName("Mark Alan Leo Rossmiller");
			} catch(IllegalArgumentException e) {
			}
			System.out.println("Testing contact.setFirstName(\"Mark Alan Leo Rossmiller\")");
			assertNotEquals("Mark Alan Leo Rossmiller", contact.getFirstName());
			
			/* lastName */
			try {
				contact.setLastName("Rossmiller");
			}
			catch (IllegalArgumentException e) {
			}
			System.out.println("Testing contact.setLastName(\"Rossmiller\")");
			assertEquals("Rossmiller", contact.getLastName());
			try {
				contact.setLastName("");
			} catch(IllegalArgumentException e) {
			}
			System.out.println("Testing contact.setLastName(\"\")");
			assertNotEquals("", contact.getLastName());
			try {
				contact.setLastName("Mark Alan Leo Rossmiller");
			} catch(IllegalArgumentException e) {
			}
			System.out.println("Testing contact.setLastName(\"Mark Alan Leo Rossmiller\")");
			assertNotEquals("Mark Alan Leo Rossmiller", contact.getLastName());
			
			/* Number */
			try {
				contact.setNumber("5154021663");
			}
			catch (IllegalArgumentException e) {
			}
			System.out.println("Testing contact.setNumber(\"5154021663\")");
			assertEquals("5154021663", contact.getNumber());
			try {
				contact.setNumber("");
			} catch(IllegalArgumentException e) {
			}
			System.out.println("Testing contact.setNumber(\"\")");
			assertNotEquals("", contact.getNumber());
			try {
				contact.setNumber("515");
			} catch(IllegalArgumentException e) {
			}
			System.out.println("Testing contact.setNumber(\"515\")");
			assertNotEquals("515", contact.getNumber());
			try {
				contact.setNumber("51540216630000");
			} catch(IllegalArgumentException e) {
			}
			System.out.println("Testing contact.setNumber(\"51540216630000\")");
			assertNotEquals("51540216630000", contact.getNumber());
			
			/* Address */
			try {
				contact.setAddress("4220 87th Street");
			}
			catch (IllegalArgumentException e) {
			}
			System.out.println("Testing contact.setAddress(\"4220 87th Street\")");
			assertEquals("4220 87th Street", contact.getAddress());
			try {
				contact.setAddress("");
			} catch(IllegalArgumentException e) {
			}
			System.out.println("Testing contact.setAddress(\"\")");
			assertNotEquals("", contact.getAddress());
			try {
				contact.setAddress("this string should be over thirty characters and not valid for the address of our contact object, so it shall be and so it ever was.");
			} catch(IllegalArgumentException e) {
			}
			System.out.println("Testing contact.setAddress(\"this string should be over thirty characters and not valid for the address of our contact object, so it shall be and so it ever was.\")");
			assertNotEquals("this string should be over thirty characters and not valid for the address of our contact object, so it shall be and so it ever was.", contact.getAddress());
			
			
			
			
		} catch(InstantiationException e) {
		}
		
	}

}
