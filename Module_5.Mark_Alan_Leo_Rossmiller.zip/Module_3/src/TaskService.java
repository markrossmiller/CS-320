import java.util.ArrayList;

public class TaskService {
	private ArrayList<Task> taskList = new ArrayList<Task>();
	
	public Task addTask(String ID, String name, String description) {
		Task task;
		int i;
		
		for(i=0;i<taskList.size();i++) {
			Task t = taskList.get(i);
			if (t.getID() == ID) {
				return(null);
			}
		}
		
		try {
			task = new Task(ID);
		} catch (InstantiationException e) {
			return(null);
		}
		try {
			task.setName(name);
		} catch (IllegalArgumentException e) {
			task = null;
			return(task);
		}
		try {
			task.setDescription(description);
		} catch (IllegalArgumentException e) {
			task = null;
			return(task);
		}

		taskList.add(task);
		return(task);
	}
	
	public Boolean deleteTask(String ID) {
		int i;
		
		for(i=0;i<taskList.size();i++) {
			Task t = taskList.get(i);
			if (t.getID() == ID) {
				taskList.remove(i);
				return(true);
			}
		}
		return(false);
	}
	
	public Boolean updateName(String ID, String name) {
		int i;
		
		for(i=0;i<taskList.size();i++) {
			Task t = taskList.get(i);
			if (t.getID() == ID) {
				try {
					t.setName(name);
					return(true);
				} catch (IllegalArgumentException e) {
				}
			}
		}
		return(false);
	}
	
	public Boolean updateDescription(String ID, String description) {
		int i;
		
		for(i=0;i<taskList.size();i++) {
			Task t = taskList.get(i);
			if (t.getID() == ID) {
				try {
					t.setDescription(description);
					return(true);
				} catch (IllegalArgumentException e) {
				}
			}
		}
		return(false);
	}
	
}
