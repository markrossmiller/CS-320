public class Task {
	private static String ID;
	private String name;
	private String description;
	
	public Task(String ID) throws InstantiationException {
		if (ID.length() <= 10 && ID.length() > 0) {
			this.ID = ID;
		}
		else {
			throw new InstantiationException();
		}
	}
	
	public String getID() {
		return(this.ID);
	}
	
	public void setName(String name) throws IllegalArgumentException {
		System.out.println(name);
		if (name.length() <= 20 && name.length() > 0) {
			this.name = name;
		}
		else {
			throw new IllegalArgumentException();
		}
	}
	
	public void setDescription(String description) throws IllegalArgumentException {
		if (description.length() <= 50 && description.length() > 0) {
			this.description = description;
		}
		else {
			throw new IllegalArgumentException();
		}
	}
	
	public String getName() {
		return(this.name);
	}
	
	public String getDescription() {
		return(this.description);
	}

}
