import static org.junit.Assert.*;
import org.junit.Test;
public class TaskServiceTest {

	@Test
	public void testingAddTask() {
		TaskService taskService = new TaskService();
		Task task;
		
		System.out.println("Testing taskService.addTask() with valid inputs");
		task = taskService.addTask("0", "Deploy Task", "This is a deployment task");
		assertNotNull(task);
		
		System.out.println("Testing taskService.addTask() with duplicate ID");
		task = taskService.addTask("0", "Other Task", "Just another task");
		assertNull(task);
		
		System.out.println("Testing taskService.addTask() with invalid inputs");
		task = taskService.addTask("1", "A very long and invalid task name meant to identify possible errors in TaskService", "Just another task");
		assertNull(task);
	}
	
	@Test
	public void testingDeleteTask() {
		TaskService taskService = new TaskService();
		Task task;
		
		task = taskService.addTask("0",  "Deploy Task",  "A deployment task");
		
		System.out.println("Testing taskService.deleteTask() with invalid ID");
		assertFalse(taskService.deleteTask("1"));
		
		System.out.println("Testing taskService.deleteTask() with valid ID");
		assertTrue(taskService.deleteTask("0"));
	}
	
	@Test
	public void testingUpdateTask() {
		TaskService taskService = new TaskService();
		Task task;
		
		task = taskService.addTask("0",  "Deploy Task", "A simple deployment task");
		
		/* name */
		System.out.println("Testing taskService.updateName() with valid input and ID");
		assertTrue(taskService.updateName("0", "Cipher Task"));
		System.out.println("Testing taskService.updateName() with invalid ID");
		assertFalse(taskService.updateName("1", "Simple Task"));
		System.out.println("Testing taskService.updateName() with invalid input");
		assertFalse(taskService.updateName("0", ""));
		
		/* description */
		System.out.println("Testing taskService.updateDescription() with valid input and ID");
		assertTrue(taskService.updateDescription("0", "This is a valid Task description"));
		System.out.println("Testing taskService.updateDescription() with invalid ID");
		assertFalse(taskService.updateDescription("1", "Task with an invalid ID"));
		System.out.println("Testing taskService.updateDescription() with invalid input");
		assertFalse(taskService.updateDescription("0", ""));
		
	}
}
