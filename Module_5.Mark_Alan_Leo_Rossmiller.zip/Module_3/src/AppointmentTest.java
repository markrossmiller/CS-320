import java.util.Date;
import static org.junit.Assert.*;
import org.junit.Test;
public class AppointmentTest {
	
	@Test
	public void testingInstance() {
		Appointment appointment = null;
		Date date = new Date();
		date.setTime(date.getTime()+60*60*24);
		try {
			appointment = new Appointment("0123456789", date, "This is a valid appointment instantiation.");
		} catch (InstantiationException e) {
		}
		System.out.println("Testing Appoinement(\"0123456789\", DATE(+24 hours), \"This is a valid appointment instantiation.\")");
		assertNotNull(appointment);
		
		appointment = null;
		try {
			appointment = new Appointment("", date, "invalid ID");
		} catch (InstantiationException e) {
		}
		
		System.out.println("Testing Appointment with null ID");
		assertNull(appointment);
		
		appointment = null;
		try {
			appointment = new Appointment("0123456789abcdef", date, "invalid ID");
		} catch (InstantiationException e) {
		}
		System.out.println("Testing Appointment with invalid ID");
		assertNull(appointment);
		
		appointment = null;
		date = new Date();
		date.setTime(date.getTime() - 24 * 60 * 60);
		try {
			appointment = new Appointment("0123456789", date, "invalid Date");
		} catch (InstantiationException e) {
		}
		System.out.println("Testing Appointment with invalid date");
		assertNull(appointment);
		
		appointment = null;
		date = new Date();
		date.setTime(date.getTime()+60*60*24);
		try {
			appointment = new Appointment("0123456789", date, "");
		} catch (InstantiationException e) {
		}
		System.out.println("Testing Appointment with null description");
		assertNull(appointment);
		
		appointment = null;
		try {
			appointment = new Appointment("0123456789", date, "This is a very long description meant to exceed the fifty character limit for descriptions in our appointment objects so we can test the limits during software execution and hopefully catch this as a bug if it works because it shouldn't since it is out of bounds.");
		} catch (InstantiationException e) {
		}
		System.out.println("Testing Appointment with long description");
		assertNull(appointment);
		
	}

}
