import static org.junit.Assert.*;
import org.junit.Test;
public class TaskTest {
	
	@Test
	public void testingInstance() {
		Task task = null;
		try {
			task = new Task("0123456789");
		} catch (InstantiationException e) {
		}
		System.out.println("Testing Task(\"0123456789\")");
		assertNotNull(task);
		
		task = null;
		try {
			task = new Task("");
		} catch (InstantiationException e) {
		}
		
		System.out.println("Testing Task(\"\")");
		assertNull(task);
		
		task = null;
		try {
			task = new Task("0123456789abcdef");
		} catch (InstantiationException e) {
		}
		System.out.println("Testing Task(\"0123456789abcdef\")");
		assertNull(task);
		
	}
	
	@Test
	public void testingSet() {
		Task task;
		try {
			task = new Task("0");
			
			/* name */
			try {
				task.setName("Deploy Task");
			}
			catch (IllegalArgumentException e) {
			}
			System.out.println("Testing task.setName(\"Deploy Task\")");
			assertEquals("Deploy Task", task.getName());
			try {
				task.setName("");
			} catch(IllegalArgumentException e) {
			}
			System.out.println("Testing task.setName(\"\")");
			assertNotEquals("", task.getName());
			try {
				task.setName("This is a very long task name which should be invalid for our class........");
			} catch(IllegalArgumentException e) {
			}
			System.out.println("Testing task.setName(\"This is a very long task name which should be invalid for our class........\")");
			assertNotEquals("This is a very long task name which should be invalid for our class........", task.getName());
			
			/* description */
			try {
				task.setDescription("This is a valid description.");
			}
			catch (IllegalArgumentException e) {
			}
			System.out.println("Testing task.setDescription(\"This is a valid description.\")");
			assertEquals("This is a valid description.", task.getDescription());
			try {
				task.setDescription("");
			} catch(IllegalArgumentException e) {
			}
			System.out.println("Testing task.setDescription(\"\")");
			assertNotEquals("", task.getDescription());
			try {
				task.setDescription("A very long description, which should be invalid for the purposes of our application. It needs to be more than fifty characters, so we will add several characters to this description in order to make the buffer significantly long enough for our test to be able to reject this case (hopefully).");
			} catch(IllegalArgumentException e) {
			}
			System.out.println("Testing task.setDescription(\"A very long description, which should be invalid for the purposes of our application. It needs to be more than fifty characters, so we will add several characters to this description in order to make the buffer significantly long enough for our test to be able to reject this case (hopefully).\")");
			assertNotEquals("A very long description, which should be invalid for the purposes of our application. It needs to be more than fifty characters, so we will add several characters to this description in order to make the buffer significantly long enough for our test to be able to reject this case (hopefully).", task.getDescription());
						
		} catch(InstantiationException e) {
		}
		
	}

}
