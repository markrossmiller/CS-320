import java.lang.InstantiationException;

public class Contact {
	private static String ID;
	private String firstName;
	private String lastName;
	private String Number;
	private String Address;
	
	public Contact(String ID) throws InstantiationException {
		if (ID.length() <= 10 && ID.length() > 0) {
			this.ID = ID;
		}
		else {
			throw new InstantiationException();
		}
	}
	
	public String getID() {
		return(this.ID);
	}
	
	public void setFirstName(String firstName) throws IllegalArgumentException {
		if (firstName.length() <=10 && firstName.length() > 0) {
			this.firstName = firstName;
		}
		else {
			throw new IllegalArgumentException();
		}
	}
	
	public void setLastName(String lastName) throws IllegalArgumentException {
		if (lastName.length() <=10 && lastName.length() > 0) {
			this.lastName = lastName;
		}
		else {
			throw new IllegalArgumentException();
		}
	}
	
	public void setNumber(String Number) throws IllegalArgumentException {
		if (Number.length() == 10) {
			this.Number = Number;
		}
		else {
			throw new IllegalArgumentException();
		}
	}
	
	public void setAddress(String Address) throws IllegalArgumentException {
		if (Address.length() <= 30 && Address.length() > 0) {
			this.Address = Address;
		}
		else {
			throw new IllegalArgumentException();
		}
	}
	
	public String getFirstName() {
		return(this.firstName);
	}
	
	public String getLastName() {
		return(this.lastName);
	}
	
	public String getNumber() {
		return(this.Number);
	}
	
	public String getAddress() {
		return(this.Address);
	}
}
