import java.util.Date;

public class Appointment {
	private static String ID;
	private Date date;
	private String description;
	
	public Appointment(String ID, Date date, String description) throws InstantiationException {
		
		if (ID.length() <= 10 && ID.length() > 0) {
			this.ID = ID;
		}
		else {
			throw new InstantiationException();
		}
		
		if (date.before(new Date())) {
			throw new InstantiationException();
		}
		else {
			this.date= date;
		}
		
		if (description.length() <= 50 && description.length() > 0) {
			this.description = description;
		}
		else {
			throw new InstantiationException();
		}
	}
	
	public String getID() {
		return(this.ID);
	}
	
	public Date getDate() {
		return(this.date);
	}
	
	public String getDescription() {
		return(this.description);
	}

}
