import static org.junit.Assert.*;
import java.util.Date;
import org.junit.Test;
public class AppointmentServiceTest {

	@Test
	public void testingAddAppointment() {
		AppointmentService appointmentService = new AppointmentService();
		Appointment appointment;
		
		Date date = new Date();
		date.setTime(date.getTime()+24*60*60);
		
		System.out.println("Testing appointmentService.addAppointment() with valid inputs");
		appointment = appointmentService.addAppointment("0123456789", date, "A simple appointment");
		assertNotNull(appointment);
		
		System.out.println("Testing appointmentService.addAppointment() with duplicate ID");
		appointment = appointmentService.addAppointment("0123456789", date, "Just another appointment");
		assertNull(appointment);
		
		date = new Date();
		date.setTime(date.getTime()-24*60*60);
		System.out.println("Testing appointmentService.addAppointment() with invalid inputs");
		appointment = appointmentService.addAppointment("1", date, "An appointment for yesterday");
		assertNull(appointment);
	}
	
	@Test
	public void testingDeleteAppointment() {
		AppointmentService appointmentService = new AppointmentService();
		Appointment appointment;
		
		Date date = new Date();
		date.setTime(date.getTime()+24*60*60);
		
		appointment = appointmentService.addAppointment("0",  date,  "A basic appointment");
		
		System.out.println("Testing appointmentService.deleteAppointment() with invalid ID");
		assertFalse(appointmentService.deleteAppointment("1"));
		
		System.out.println("Testing appointmentService.deleteAppointment() with valid ID");
		assertTrue(appointmentService.deleteAppointment("0"));
	}
	
}
