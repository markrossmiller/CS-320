import java.util.ArrayList;

public class ContactService {
	private ArrayList<Contact> contactList = new ArrayList<Contact>();
	
	public Contact addContact(String ID, String firstName, String lastName, String Number, String Address) {
		Contact contact;
		int i;
		
		for(i=0;i<contactList.size();i++) {
			Contact c = contactList.get(i);
			if (c.getID() == ID) {
				return(null);
			}
		}
		
		try {
			contact = new Contact(ID);
		} catch (InstantiationException e) {
			return(null);
		}
		try {
			contact.setFirstName(firstName);
		} catch (IllegalArgumentException e) {
			contact = null;
			return(contact);
		}
		try {
			contact.setLastName(lastName);
		} catch (IllegalArgumentException e) {
			contact = null;
			return(contact);
		}
		try {
			contact.setNumber(Number);
		} catch (IllegalArgumentException e) {
			contact = null;
			return(contact);
		}
		try {
			contact.setAddress(Address);
		} catch (IllegalArgumentException e) {
			contact = null;
			return(contact);
		}
		contactList.add(contact);
		return(contact);
	}
	
	public Boolean deleteContact(String ID) {
		int i;
		
		for(i=0;i<contactList.size();i++) {
			Contact c = contactList.get(i);
			if (c.getID() == ID) {
				contactList.remove(i);
				return(true);
			}
		}
		return(false);
	}
	
	public Boolean updateFirstName(String ID, String firstName) {
		int i;
		
		for(i=0;i<contactList.size();i++) {
			Contact c = contactList.get(i);
			if (c.getID() == ID) {
				try {
					c.setFirstName(firstName);
					return(true);
				} catch (IllegalArgumentException e) {
				}
			}
		}
		return(false);
	}
	
	public Boolean updateLastName(String ID, String lastName) {
		int i;
		
		for(i=0;i<contactList.size();i++) {
			Contact c = contactList.get(i);
			if (c.getID() == ID) {
				try {
					c.setLastName(lastName);
					return(true);
				} catch (IllegalArgumentException e) {
				}
			}
		}
		return(false);
	}
	
	public Boolean updateNumber(String ID, String Number) {
		int i;
		
		for(i=0;i<contactList.size();i++) {
			Contact c = contactList.get(i);
			if (c.getID() == ID) {
				try {
					c.setNumber(Number);
					return(true);
				} catch (IllegalArgumentException e) {
				}
			}
		}
		return(false);
	}
	
	public Boolean updateAddress(String ID, String Address) {
		int i;
		
		for(i=0;i<contactList.size();i++) {
			Contact c = contactList.get(i);
			if (c.getID() == ID) {
				try {
					c.setAddress(Address);
					return(true);
				} catch (IllegalArgumentException e) {
				}
			}
		}
		return(false);
	}
}
