import java.util.ArrayList;
import java.util.Date;

public class AppointmentService {
	private ArrayList<Appointment> appointmentList = new ArrayList<Appointment>();
	
	public Appointment addAppointment(String ID, Date date, String description) {
		Appointment appointment;
		int i;
		
		for(i=0;i<appointmentList.size();i++) {
			Appointment a = appointmentList.get(i);
			if (a.getID() == ID) {
				return(null);
			}
		}
		
		try {
			appointment = new Appointment(ID, date, description);
		} catch (InstantiationException e) {
			return(null);
		}

		appointmentList.add(appointment);
		return(appointment);
	}
	
	public Boolean deleteAppointment(String ID) {
		int i;
		
		for(i=0;i<appointmentList.size();i++) {
			Appointment a = appointmentList.get(i);
			if (a.getID() == ID) {
				appointmentList.remove(i);
				return(true);
			}
		}
		return(false);
	}
	
}
